# @chemistry/molecule3d
[![Build Status](https://travis-ci.com/vreshch/molecule3d.svg?token=KeX5irpaztoiyZmMEffK&branch=master)](https://travis-ci.com/vreshch/molecule3d)

Simple library to support 3D infinite molecules;

## Include following clases:
  * Molecule3D
  * Atom
  * Bond

## Commands:
  * Run unit tests: `npm run test`
  * Start TDD flow: `npm run tdd`
  * Run linter verification: `npm run lint`
  * Run linter verification & fix: `npm run lintfix`
  * Build project: `npm run build`

## Technical description :
  * Typescript 2.1 (export typings)
  * Isomorphic (can be used with node & with browsers )
  * Compiled to UMD (can be used as CommonJS, AMD & direct module include syntax)
  * Build with TDD in mind (tests with jasmine)
  * height code coverage (detailed report with Istanbul)
