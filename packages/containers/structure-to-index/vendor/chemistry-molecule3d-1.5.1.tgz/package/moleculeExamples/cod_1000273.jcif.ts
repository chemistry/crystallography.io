export default {
    "id": 1000273,
    "a":"5.0881(2)",
    "b":"5.0881(2)",
    "c":"12.7245(4)",
    "alpha":"90",
    "beta":"90",
    "gamma":"90",
    "vol":"329.4",
    "chemname":"Rubidium ammonium tetrafluoroaluminate (.1/.9/1)",
    "calcformula":"Al F4 H3.72 N0.93 Rb0.07",
    "__authors":[{"name":"Jouanneaux, A","link":"Jouanneaux A."},{"name":"Leble, A","link":"Leble A."},{"name":"Pannetier, J","link":"Pannetier J."},{"name":"Fourquet, J L","link":"Fourquet J. L."}],
    "sg":"I 4/m c m",
    "sgHall":"-I 4 2c",
    "Rall":"0.163",
    "loops":[{
        "data":[
          ["N1","N3-","0.","0.5","0.25","0.93"],
          ["Rb1","Rb1+","0.","0.5","0.25","0.07"],
          ["Al1","Al3+","0.","0.","0.","1."],
          ["F1","F1-","0.","0.","0.1386(2)","1."],
          ["F2","F1-","0.2108(6)","0.7108(6)","0.","1."],
          ["H1","H1+","-0.0004(17)","0.3353(13)","0.2049(6)","0.465"]
        ],
        "columns":[
          "_atom_site_label",
          "_atom_site_type_symbol",
          "_atom_site_fract_x",
          "_atom_site_fract_y",
          "_atom_site_fract_z",
          "_atom_site_occupancy"
        ]
     }]
}
