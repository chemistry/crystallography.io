export default {
    "a":"5.0125(3)",
    "b":"5.0125(3)",
    "c":"3.9873(2)",
    "alpha":"90",
    "beta":"90",
    "gamma":"120.",
    "vol":"86.76",
    "calcformula":"La Ni5",
    "__authors":[
      {"name":"Kisi, E. H.","link":"Kisi E. H."},
      {"name":"Buckley, C. E.","link":"Buckley C. E."},
      {"name":"Gray, E. M.","link":"Gray E. M."}
    ],
    "sg":"P 6/m m m",
    "sgHall":"-P 6  2",
    "loops":[{
      "data":[
        ["La","La","0","0","0","1"],
        ["Ni2","Ni","0.5000","0","0.5000","1"],
        ["Ni1","Ni","0.3333","0.6667","0","1"]
      ],
      "columns":[
        "_atom_site_label",
        "_atom_site_type_symbol",
        "_atom_site_fract_x",
        "_atom_site_fract_y",
        "_atom_site_fract_z",
        "_atom_site_occupancy"
      ]
    }],
    "id":1000025,
    "articleHtml":"<i>Journal of Alloys and Compounds</i> (<b>1992</b>) 185, 2 369-384"
};
