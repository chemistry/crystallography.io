import { Vec3 } from "@chemistry/math";
import { Atom } from "./Atom";

export class Bond {
    constructor(
        public atom1: Atom,
        public atom2: Atom,
        public order: number = 1,
    ) {
    }

    public destroy() {
        this.atom1 = null;
        this.atom2 = null;
    }
}
