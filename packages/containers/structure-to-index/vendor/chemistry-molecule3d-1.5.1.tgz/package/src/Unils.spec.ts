import { Matrix3x4 } from "@chemistry/math";
import { Utils } from "./Unils";

describe("Utils.SymetryCodeToMatrix", () => {

    beforeEach(() => {
        spyOn(Utils as any, "SymCodeSym1").and.callThrough();
        spyOn(Utils as any, "SymCodeSym2").and.callThrough();
        spyOn(Utils as any, "SymCodeSym3").and.callThrough();
        spyOn(Utils as any, "SymCodeSym4").and.callThrough();
        spyOn(Utils as any, "SymCodeSym5").and.callThrough();
    });

    it("should throw error when code contains not 3 parts", () => {
        expect(() => {
            Utils.SymetryCodeToMatrix("1,2,3,4");
        }).toThrow();
    });

    it("should split expression and call SymCodeSym1 3 times", () => {
        const m = Utils.SymetryCodeToMatrix("x,y,z");
        expect((Utils as any).SymCodeSym1).toHaveBeenCalledTimes(3);
    });

    it("should trow error then returned values is not a number", () => {
        ((Utils as any).SymCodeSym1 as any).and.returnValue([0, 0, 0, "wrong"]);
        expect(() => {
            Utils.SymetryCodeToMatrix("x,y,z");
        }).toThrow();
    });

    it("should build matrix based on returned value", () => {
        ((Utils as any).SymCodeSym1 as any).and.returnValue([0, 1, 0, 0]);
        const m = Utils.SymetryCodeToMatrix("x,y,z");
        expect(m.toString()).toEqual("(0.000,1.000,0.000,0.000,0.000,1.000,0.000,0.000,0.000,1.000,0.000,0.000)");
    });

    // x+1/2,-y+1/2,z-1/2
    it("should process symetry code: x+1/2,-y+1/2,z-1/2", () => {
        const m = Utils.SymetryCodeToMatrix("x+1/2,-y+1/2,z-1/2");
        expect(m.toString()).toEqual("(1.000,0.000,0.000,0.500,0.000,-1.000,0.000,0.500,0.000,0.000,1.000,-0.500)");
    });
    // -x+1/2,-y+1/2,-z
    it("should process symetry code: -x+1/2,-y+1/2,-z", () => {
        const m = Utils.SymetryCodeToMatrix("-x+1/2,-y+1/2,-z");
        expect(m.toString()).toEqual("(-1.000,0.000,0.000,0.500,0.000,-1.000,0.000,0.500,0.000,0.000,-1.000,0.000)");
    });
    // -x+1/2,-y-1/2,-z+1/2
    it("should process symetry code: -x+1/2,-y-1/2,-z+1/2", () => {
        const m = Utils.SymetryCodeToMatrix("-x+1/2,-y-1/2,-z+1/2");
        expect(m.toString()).toEqual("(-1.000,0.000,0.000,0.500,0.000,-1.000,0.000,-0.500,0.000,0.000,-1.000,0.500)");
    });

    describe("SymCodeSym1", () => {
        const SymCodeSym1 = (Utils as any).SymCodeSym1;
        it("should return zero vector by default", () => {
            expect(SymCodeSym1("")).toEqual([0, 0, 0, 0]);
        });

        it("should call SymCodeSym2 for each chunk", () => {
            SymCodeSym1("x-y+1/2");
            expect((Utils as any).SymCodeSym2).toHaveBeenCalledTimes(2);
        });

        it("should sumup results of SymCodeSym2 calls", () => {
            ((Utils as any).SymCodeSym2 as any).and.returnValue([0, 0, 1, 0]);
            const m = SymCodeSym1("x-y+1/2");
            expect(m).toEqual([0, 0, 2, 0]);
        });
    });

    describe("SymCodeSym2", () => {
        const SymCodeSym2 = (Utils as any).SymCodeSym2;
        it("should return zero vector by default", () => {
            expect(SymCodeSym2("")).toEqual([0, 0, 0, 0]);
        });

        it("should call SymCodeSym3 for each chunk", () => {
            SymCodeSym2("x-y");
            expect((Utils as any).SymCodeSym3).toHaveBeenCalledTimes(2);
        });

        it("should call SymCodeSym3 for each chunk & ignore init sign", () => {
            SymCodeSym2("-x-y");
            expect((Utils as any).SymCodeSym3).toHaveBeenCalledTimes(2);
        });
    });

    describe("SymCodeSym3", () => {
          const SymCodeSym3 = (Utils as any).SymCodeSym3;

          it("should call process x as varible", () => {
              const res = SymCodeSym3("x");
              expect((Utils as any).SymCodeSym5).toHaveBeenCalledWith("x", "x");
          });
          it("should call process y as varible", () => {
              const res = SymCodeSym3("y");
              expect((Utils as any).SymCodeSym5).toHaveBeenCalledWith("y", "y");
          });
          it("should call process z as varible", () => {
              const res = SymCodeSym3("z");
              expect((Utils as any).SymCodeSym5).toHaveBeenCalledWith("z", "z");
          });
          it("should call process constants", () => {
              const res = SymCodeSym3("1/2");
              expect((Utils as any).SymCodeSym4).toHaveBeenCalledWith("1/2");
          });
    });

    describe("SymCodeSym4", () => {
        const SymCodeSym4 = (Utils as any).SymCodeSym4;

        it("should process numbers", () => {
            const res = SymCodeSym4("0.5");
            expect(res).toEqual(0.5);
        });

        it("should process numbers with fractions", () => {
            const res = SymCodeSym4("1/4");
            expect(res).toEqual(0.25);
        });

        it("should process numbers with coma", () => {
            const res = SymCodeSym4("1,5");
            expect(res).toEqual(1.5);
        });

        it("should return for unprocessed NaN", () => {
            const res = SymCodeSym4("r");
            expect(res).toEqual(NaN);
        });
    });

    describe("SymCodeSym5", () => {
        const SymCodeSym5 = (Utils as any).SymCodeSym5;

        it("should process statement: x", () => {
            const res = SymCodeSym5("x", "x");
            expect(res).toEqual(1);
        });

        it("should process statement: 1/2x", () => {
            const res = SymCodeSym5("1/2x", "x");
            expect(res).toEqual(0.5);
        });

        it("should process statement: 0.25x", () => {
            const res = SymCodeSym5("0.25x", "x");
            expect(res).toEqual(0.25);
        });

        it("should process statement: 0.75*x", () => {
            const res = SymCodeSym5("0.75*x", "x");
            expect(res).toEqual(0.75);
        });

        it("throw error then parse code is wrong", () => {
            expect(() => {
                SymCodeSym5("0.75*x", "y");
            }).toThrow();
        });
    });
});
