import { SpaceGroup } from "@crystallography/space-groups";
import { CellAtom } from "./CellAtom";
import { UnitCell } from "./UnitCell";

export class CellAtomsBuilder {

    private id = 101;

    private type: string = "C";
    private label: string = "C1";
    private x: number = 0;
    private y: number = 0;
    private z: number = 0;
    private occupancy = 0;
    private uiso = 0;

    private a = 1;
    private b = 1;
    private c = 1;
    private alpha = 90;
    private beta  = 90;
    private gama  = 90;
    private sg: SpaceGroup = null;

    public withUnitCellParams(
        a: number, b: number, c: number,
        alpha: number, beta: number, gamma: number,
    ) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.alpha = alpha;
        this.beta  = beta;
        this.gama  = gamma;
        return this;
    }

    public withSpaceGroup(sg: SpaceGroup) {
        this.sg = sg;
        return this;
    }

    public withType(type: string) {
        this.type = type;
        this.label = type;
        return this;
    }

    public withCoordinates(
        x: number,
        y: number,
        z: number,
    ) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }

    public build(): CellAtom {
        let uc: UnitCell;
        if (this.sg) {
            uc = new UnitCell(
                this.a, this.b, this.c,
                this.alpha, this.beta, this.gama,
                this.sg,
            );
        } else {
          uc = new UnitCell(
              this.a, this.b, this.c,
              this.alpha, this.beta, this.gama,
          );
        }

        const atom = new CellAtom({
            type: this.type,
            label: this.label,
            x: this.x,
            y: this.y,
            z: this.z,
            occupancy: this.occupancy,
            uiso: this.uiso,
            asembly: "",
            group: "",
        });
        atom.setId(101);
        atom.setUnitCell(uc);

        return atom;
    }
}
