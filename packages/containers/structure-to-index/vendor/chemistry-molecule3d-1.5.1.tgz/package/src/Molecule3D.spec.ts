import benzene from "../moleculeExamples/benzene.jcif";
import cod_1000025 from "../moleculeExamples/cod_1000025.jcif";
import cod_1000273 from "../moleculeExamples/cod_1000273.jcif";
import cod_1100231 from "../moleculeExamples/cod_1100231.jcif";
import cod_1100240 from "../moleculeExamples/cod_1100240.jcif";

import { Atom } from "./Atom";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { MoleculeIO } from "./io";
import jcif from "./io/MoleculeReaderJCIF.spec.jcif";

import { Matrix3x4 } from "@chemistry/math";
import { Link } from "./Link";
import { Molecule3D } from "./Molecule3D";
import { MoleculeConnector } from "./MoleculeConnector";
import { UnitCell } from "./UnitCell";

describe("Molecule3D", () => {

    beforeEach(() => {
        // MOCK external dependency
        spyOn(MoleculeConnector, "buildConnectivity").and.callThrough();
    });

    it("should export class", () => {
        expect(Molecule3D).toBeDefined();
    });

    it("should create instance", () => {
        const mol = new Molecule3D();
        expect(mol).toBeDefined();
    });

    it("should initialize fields with", () => {
        const mol = new Molecule3D();
        expect(mol.unitCell).toBeDefined();
    });

    describe("clear", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("should reset fields values ", () => {
            (sut as any).title = "MOCK";
            (sut.cellAtoms as any[]).push({});

            sut.clear();

            expect(sut.title).toEqual("");
            expect(sut.cellAtoms).toEqual([]);
        });
    });

    describe("addCellAtom", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("should add cell atom & set id & unit cell", () => {
              sut.addCellAtom({
                type: "C",
                label: "C1",
                x: 0,
                y: 0,
                z: 0,
                occupancy: 1,
                uiso: 0,
                group: "",
                asembly: "",
              });

              expect(sut.cellAtoms.length).toEqual(1);
              expect(sut.cellAtoms[0].id).toEqual(1);
              expect(sut.cellAtoms[0].unitCell).toEqual(sut.unitCell);
        });

        it("should throw exeption when molecule connectivity alredy initialized", () => {
            sut.connectAtoms();

            expect(() => {
              sut.addCellAtom({ type: "C",
                label: "C1",  x: 0, y: 0, z: 0, occupancy: 1, uiso: 0, group: "", asembly: "",
              });
            }).toThrow();
        });
    });

    describe("connectAtoms", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("should call MoleculeConnector", () => {
            sut.connectAtoms();
            expect(MoleculeConnector.buildConnectivity).toHaveBeenCalled();
        });

        it("should call MoleculeConnector only once", () => {
            sut.connectAtoms();
            sut.connectAtoms();
            expect(MoleculeConnector.buildConnectivity).toHaveBeenCalledTimes(1);
        });
    });

    describe("load", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
            spyOn(MoleculeIO, "loadMolecule");
            spyOn(sut, "connectAtoms");
        });

        it("should call loadMolecule form IO utils", () => {
            sut.load({data: "MOCK-DATA"});

            expect(MoleculeIO.loadMolecule).toHaveBeenCalled();
            expect(sut.connectAtoms).toHaveBeenCalled();
        });
    });

    describe("export", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
            spyOn(MoleculeIO, "exportMolecule");
        });

        it("should call loadMolecule form IO utils", () => {
            sut.export();

            expect(MoleculeIO.exportMolecule).toHaveBeenCalled();
        });
    });

    describe("addAtom", () => {
        let sut: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            sut = new Molecule3D();
            builder = new CellAtomsBuilder();
        });

        it("should add atom to list", () => {
            const ca = builder.withType("F").build();
            const m = UnitCell.getMatrixFromSymetry("x,y,z");
            const atom = new Atom(ca, m);

            sut.addAtom(atom);

            expect(sut.atoms).toEqual([atom]);
        });
    });

    describe("load / export", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("should transform jcif to jmol", () => {
            sut.load(jcif);
            const jmol = sut.export();

            expect(jmol[0].atoms.length).toEqual(jcif.loops[0].data.length);
            expect(jmol[0].atoms[0][4]).toEqual(true);
            expect(jmol[0].atoms[0][5]).toEqual("x,y,z");
            expect(jmol[0].id).toEqual(jcif.id);
        });

        it("should correctry calculate fragmetns for height symetry molecules", () => {
            sut.load(cod_1000273);
        });

        it("should correctry calculate fragmetns for height symetry molecules", () => {
            sut.load(cod_1100231);
            const isOrganic = sut.isOrganic();
            sut.addAtomLayers(5, 1000);
        });

        it("should limit added atoms count", () => {
            sut.load(cod_1100240);
            const isOrganic = sut.isOrganic();
            const limit = Math.max(sut.getAtomsCount(), 10);
            sut.addAtomLayers(5, limit * 4);

            expect(sut.getAtomsCount()).toBeLessThan(10000);
        });

    });

    describe("functional testing", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("shoud combine links for height symetry molecules", () => {
            sut.load(cod_1000025);
            expect(sut.cellAtoms[0].getLinks().length).toEqual(7);
        });
    });

    describe("isOrganic()", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("shoud detect inorganic molecules", () => {
            sut.load(cod_1000025);
            const res = sut.isOrganic();

            expect(res).toBe(false);
        });

        it("shoud detect inorganic molecules", () => {
            sut.load(benzene);
            const res = sut.isOrganic();

            expect(res).toBe(true);
        });

        it("should not consider empty molecule as organic", () => {
            const res = sut.isOrganic();

            expect(res).toBe(false);
        });
    });

    describe("describe", () => {
        let sut: Molecule3D;

        beforeEach(() => {
            sut = new Molecule3D();
        });

        it("should call destroy without error", () => {
            sut.load(benzene);

            expect(() => {
                sut.destroy();
            }).not.toThrow();
        });
    });

});
