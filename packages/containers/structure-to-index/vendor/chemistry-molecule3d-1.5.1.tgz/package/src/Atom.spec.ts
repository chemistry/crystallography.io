import { Atom } from "./Atom";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { UnitCell } from "./UnitCell";

describe("Atom", () => {
    let builder: CellAtomsBuilder;

    beforeEach(() => {
        builder = new CellAtomsBuilder();
    });

    it("should create instance of C type", () => {
        const ca = builder.withType("C").build();
        const m = UnitCell.getMatrixFromSymetry("x,y,z");

        const atom = new Atom(ca, m);

        expect(atom).toBeDefined();
    });

    describe("getColor", () => {

        it("should return color of parent", () => {
            const ca = builder.withType("F").build();
            const m = UnitCell.getMatrixFromSymetry("x,y,z");

            const atom = new Atom(ca, m);

            expect(atom.getColor()).toEqual(ca.element.color);
        });
    });
});
