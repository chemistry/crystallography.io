import { Matrix3x3, Matrix3x4, Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { Utils } from "./Unils";

export class UnitCell {
    /**
     * Will construct Transformation Matrix from Crystallographic notation
     * e.g. x,y,z -x+1/2, -y, z+1/2
     */
    public static getMatrixFromSymetry(symetryCode: string): Matrix3x4 {
        return Utils.SymetryCodeToMatrix(symetryCode);
    }

    public static getBoxTransactions(): Vec3[] {
         return [
             new Vec3(0, 0, 0),
             new Vec3(0, 0, 1),
             new Vec3(0, 0, -1),
             new Vec3(0, 1, 0),
             new Vec3(0, 1, 1),
             new Vec3(0, 1, -1),
             new Vec3(0, -1, 0),
             new Vec3(0, -1, 1),
             new Vec3(0, -1, -1),
             new Vec3(1, 0, 0),
             new Vec3(1, 0, 1),
             new Vec3(1, 0, -1),
             new Vec3(1, 1, 0),
             new Vec3(1, 1, 1),
             new Vec3(1, 1, -1),
             new Vec3(1, -1, 0),
             new Vec3(1, -1, 1),
             new Vec3(1, -1, -1),
             new Vec3(-1, 0, 0),
             new Vec3(-1, 0, 1),
             new Vec3(-1, 0, -1),
             new Vec3(-1, 1, 0),
             new Vec3(-1, 1, 1),
             new Vec3(-1, 1, -1),
             new Vec3(-1, -1, 0),
             new Vec3(-1, -1, 1),
             new Vec3(-1, -1, -1),
         ];
    }

    public readonly volume: number;
    public readonly symetryList: Matrix3x4[] = [];
    private mOrthMatrix: Matrix3x3;
    private mOrthMatrixInvert: Matrix3x3;

    constructor(
        public readonly a: number,
        public readonly b: number,
        public readonly c: number,
        public readonly alpha: number,
        public readonly beta: number,
        public readonly gamma: number,
        public readonly spaceGroup: SpaceGroup = SpaceGroup.getById(1)) {

        this.init();
    }

    /**
     * Convert fractional coordinates to Orth
     */
    public fractToOrth(coord: Vec3): Vec3 {
        return this.mOrthMatrix.project(coord);
    }

    /**
     * Convert Orth coordinates to fractional
     */
    public orthToFract(coord: Vec3): Vec3 {
        return this.mOrthMatrixInvert.project(coord);
    }

    private init(): void {
         // PREPARE PROJECTION MATRIXES
         const pAlpha = this.alpha * 0.017453292519943295; // pi/180 ;
         const pBeta  = this.beta  * 0.017453292519943295;
         const pGamma = this.gamma * 0.017453292519943295;
         const v = (Math.sqrt(1 - Math.cos(pAlpha) * Math.cos(pAlpha) - Math.cos(pBeta) * Math.cos(pBeta)
           - Math.cos(pGamma) * Math.cos(pGamma) + 2 * Math.cos(pAlpha) * Math.cos(pBeta) * Math.cos(pGamma)));
         const aa = (Math.sin(pAlpha) / this.a / v);
         const bb = (Math.sin(pBeta) / this.b / v);
         const cc = (Math.sin(pGamma) / this.c / v);
         const alphaa = (Math.acos((Math.cos(pBeta) * Math.cos(pGamma)
           - Math.cos(pAlpha)) / Math.sin(pBeta) / Math.sin(pGamma)));
         const betaa = (Math.acos((Math.cos(pAlpha) * Math.cos(pGamma)
           - Math.cos(pBeta)) / Math.sin(pAlpha) / Math.sin(pGamma)));
         const gammaa = (Math.acos((Math.cos(pAlpha) * Math.cos(pBeta)
           - Math.cos(pGamma)) / Math.sin(pAlpha) / Math.sin(pBeta)));

         this.mOrthMatrix = new Matrix3x3();
         this.mOrthMatrix.set(0, 0, (this.a));
         this.mOrthMatrix.set(0, 1, (this.b * Math.cos(pGamma)));
         this.mOrthMatrix.set(0, 2, (this.c * Math.cos(pBeta)));
         this.mOrthMatrix.set(1, 0, 0);
         this.mOrthMatrix.set(1, 1, (this.b * Math.sin(pGamma)));
         this.mOrthMatrix.set(1, 2, (-this.c * Math.sin(pBeta) * Math.cos(alphaa)));
         this.mOrthMatrix.set(2, 0, 0);
         this.mOrthMatrix.set(2, 1, 0);
         this.mOrthMatrix.set(2, 2, (1 / cc));
         this.mOrthMatrixInvert = Matrix3x3.inverse(this.mOrthMatrix);
         (this as any).volume = v;

         for (const symStr of this.spaceGroup.symetryList) {
             const sym = UnitCell.getMatrixFromSymetry(symStr);
             this.symetryList.push(sym);
         }
     }
}
