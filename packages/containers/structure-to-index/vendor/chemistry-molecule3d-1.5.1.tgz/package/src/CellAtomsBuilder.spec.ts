import { Matrix3x4, Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { CellAtom } from "./CellAtom";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { Link } from "./Link";
import { UnitCell } from "./UnitCell";

describe("CellAtomsBuilder", () => {
    let builder: CellAtomsBuilder;

    beforeEach(() => {
        builder = new CellAtomsBuilder();
    });

    it("should be able to create instance", () => {
        expect(builder).toBeDefined();
    });

    describe("build", () => {
        it("should create default CellAtom instance", () => {
            const ca = builder.build();
            expect(ca).toBeDefined();
        });
    });

    describe("withUnitCellParams", () => {
        it("should set unit cell params", () => {
            const res = builder.withUnitCellParams(2, 3, 4, 60, 70, 90);
            const ca: CellAtom = res.build();

            expect(res).toEqual(builder);
            expect(ca.unitCell.a).toEqual(2);
            expect(ca.unitCell.b).toEqual(3);
            expect(ca.unitCell.alpha).toEqual(60);
            expect(ca.unitCell.beta).toEqual(70);
            expect(ca.unitCell.gamma).toEqual(90);
        });
    });

    describe("withSpaceGroup", () => {
        it("should set space group params", () => {
          const sg = SpaceGroup.getById(2);
          const res = builder.withSpaceGroup(sg);
          const ca: CellAtom = res.build();

          expect(res).toEqual(builder);
          expect(ca.unitCell.spaceGroup).toEqual(sg);
        });
    });

    describe("withCoordinates", () => {
        it("should set position params", () => {
            const res = builder.withCoordinates(1, 2, 3);
            const ca: CellAtom = res.build();

            expect(res).toEqual(builder);
            expect(ca.position.x).toBeCloseTo(1);
            expect(ca.position.y).toBeCloseTo(2);
            expect(ca.position.z).toBeCloseTo(3);
        });
    });

    describe("withType", () => {
        it("should set atom type", () => {
            const res = builder.withType("F");
            const ca: CellAtom = res.build();

            expect(res).toEqual(builder);
            expect(ca.element.symbol).toEqual("F");
        });
    });
});
