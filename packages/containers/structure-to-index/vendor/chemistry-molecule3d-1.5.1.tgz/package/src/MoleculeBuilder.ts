import { Matrix3x4, Vec3 } from "@chemistry/math";
import { Bond } from "./Bond";
import { CellAtom } from "./CellAtom";
import { Molecule3D } from "./Molecule3D";
import { UnitCell } from "./UnitCell";

export class MoleculeBuilder {

    public static addUniqueAtoms(molecule: Molecule3D) {
        MoleculeBuilder.addAtomsBySymetry(molecule, ["x,y,z"]);
    }

    public static addAtomsBySymetry(molecule: Molecule3D, symetryList: string[]) {
        const unitCell = molecule.unitCell;

        for (const symetryCode of symetryList) {
            const symetry = UnitCell.getMatrixFromSymetry(symetryCode);

            for (const catom of molecule.cellAtoms) {
                MoleculeBuilder.addAtomWithBonds(molecule, catom, symetry);
            }
        }
    }

    public static addAtomWithBonds(molecule: Molecule3D, catom: CellAtom, symetry: Matrix3x4) {
        const unitCell = molecule.unitCell;
        const predictedPostion = symetry.project(catom.fractional);

        const zatom = catom.getChild(predictedPostion);

        let atom = zatom;
        if (!zatom) {
            atom = catom.createAtom(symetry, true);
            molecule.addAtom(atom);
        }

        const links = catom.getLinks();

        for (const link of links) {
            // connected atom
            const conAtom = link.atom;

            // connected atom predicted position
            const predicted = symetry.project(link.fractional);
            const xatom = conAtom.getChild(predicted);

            // Atom alredy exists ..
            if (xatom) {
                const bond = new Bond(atom, xatom, 1);
                molecule.bonds.push(bond);
            }
        }
    }

    public static addAtomLayers(molecule: Molecule3D, count: number, atomsLimit: number) {
        let currentLimit = atomsLimit;

        for (let i = 0; i < count; i ++) {
            const addedAtoms = MoleculeBuilder.addConnectedAtom(molecule);
            currentLimit = currentLimit - addedAtoms;
            if (addedAtoms === 0 || currentLimit < 0) {
                return;
            }
        }
    }

    public static addConnectedAtom(molecule: Molecule3D): number {
        const cellAtoms = molecule.cellAtoms;
        const unitCell = molecule.unitCell;
        let atomsAdded = 0;

        for (const catom of cellAtoms) {
            for (const atom of catom.getChildren()) {
                const atomSymetry = atom.symetry;

                for (const link of catom.getLinks()) {
                    const conAtom = link.atom;
                    const symetry = link.symetry;

                    const totalSymetry = atomSymetry.multiply(symetry);

                    let predicted = symetry.project(conAtom.fractional);
                    predicted = atomSymetry.project(predicted);
                    const xatom = conAtom.getChild(predicted);

                    if (!xatom) {
                        MoleculeBuilder.addAtomWithBonds(molecule, conAtom, totalSymetry);
                        atomsAdded ++;
                    }
                }

            }
        }

        return atomsAdded;
    }
}
