import { Bond } from "./Bond";

describe("Bond", () => {
    it("should be able to create instance", () => {
        const bond  =  new Bond({} as any, {} as any, 1);
        expect(bond).toBeDefined();
    });
});
