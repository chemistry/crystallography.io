import { SpaceGroup } from "@crystallography/space-groups";
import benzeneJcif from "../moleculeExamples/benzene.jcif";
import { Atom } from "./Atom";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { MoleculeIO } from "./io";
import { Molecule3D } from "./Molecule3D";
import { MoleculeBuilder } from "./MoleculeBuilder";
import { MoleculeConnector } from "./MoleculeConnector";
import { UnitCell } from "./UnitCell";

describe("MoleculeBuilder", () => {
    let sut: MoleculeBuilder;

    beforeEach(() => {
        sut = MoleculeBuilder;
    });

    it("should define export", () => {
        expect(MoleculeBuilder).toBeDefined();
    });

    describe("addUniqueAtoms", () => {
        let molecule: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            molecule = new Molecule3D();
            builder = new CellAtomsBuilder();
            const ca1 = builder
              .withType("C")
              .withCoordinates(0, 0, 0)
              .build();
            molecule.addCellAtom(ca1);
        });

        it("should add all atoms from cell atoms", () => {
            MoleculeBuilder.addUniqueAtoms(molecule);
            expect(molecule.cellAtoms.length).toEqual(molecule.atoms.length);
        });
    });

    describe("addAtomsBySymetry", () => {
        let molecule: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            molecule = new Molecule3D();
            molecule.unitCell = new UnitCell(10, 10, 10, 90, 90, 90, SpaceGroup.getById(1));
            builder = new CellAtomsBuilder();
        });

        it("should not add existing atom twise", () => {
            const ca1 = builder.withType("C").withCoordinates(0, 0, 0).build();
            molecule.addCellAtom(ca1);

            MoleculeBuilder.addAtomsBySymetry(molecule, ["x,y,x", "-x,-y,-z"]);
            expect(molecule.cellAtoms.length).toEqual(molecule.atoms.length);
        });

        it("should connect atoms when added", () => {
            const ca1 = builder.withCoordinates(0.5, 0.5, 0.5).build();
            const ca2 = builder.withCoordinates(0.64, 0.5, 0.5).build();
            molecule.addCellAtom(ca1);
            molecule.addCellAtom(ca2);
            molecule.connectAtoms();

            MoleculeBuilder.addAtomsBySymetry(molecule, ["x,y,x"]);

            expect((molecule as any).bonds.length).toEqual(1);
        });
    });

    describe("addConnectedAtom", () => {
          let molecule: Molecule3D;

          beforeEach(() => {
              molecule =  new Molecule3D();
          });

          it("should extend benzene molecule", () => {
              molecule.load(benzeneJcif);
              MoleculeBuilder.addConnectedAtom(molecule);

              const jmol = molecule.export();

              const uniqueAtoms = jmol[0].atoms.filter((line) => {
                  return line[4];
              });

              expect(jmol[0].atoms.length).toEqual(10);
              expect(uniqueAtoms.length).toEqual(6);
          });
    });

    describe("addAtomLayers", () => {
        let molecule: Molecule3D;

        beforeEach(() => {
            molecule =  new Molecule3D();
        });

        it("should extend benzene molecule", () => {
            molecule.load(benzeneJcif);
            MoleculeBuilder.addAtomLayers(molecule, 10, 1000);

            const jmol = molecule.export();

            const uniqueAtoms = jmol[0].atoms.filter((line) => {
                return line[4];
            });

            expect(jmol[0].atoms.length).toEqual(12);
            expect(jmol[0].bonds.length).toEqual(12);
            expect(uniqueAtoms.length).toEqual(6);
        });
    });
});
