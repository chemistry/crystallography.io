import { Molecule3D } from "../Molecule3D";
import { MoleculeReaderJCIF } from "./MoleculeReaderJCIF";
import jcif from "./MoleculeReaderJCIF.spec.jcif";

describe("MoleculeReaderJCIF", () => {

    it("should definde export", () => {
        expect(MoleculeReaderJCIF).toBeDefined();
    });

    describe("loadMolecule", () => {
        let sut: Molecule3D;
        beforeEach(() => {
            sut = new Molecule3D();
            MoleculeReaderJCIF.loadMolecule(sut, jcif);
        });

        it("should set title", () => {
            expect(sut.id).toEqual("1000004");
            expect(sut.title).toEqual("");
        });

        it("should init unit cell", () => {
            expect(sut.unitCell.a).toEqual(9.899);
            expect(sut.unitCell.b).toEqual(11.729);
            expect(sut.unitCell.c).toEqual(12.259);

            expect(sut.unitCell.alpha).toEqual(103.442);
            expect(sut.unitCell.beta).toEqual(96.291);
            expect(sut.unitCell.gamma).toEqual(95.560);
            // P -1
            expect(sut.unitCell.spaceGroup.id).toEqual(2);
        });

        it("should init cell atoms", () => {
            expect(sut.cellAtoms.length).toEqual(63);
        });
    });

    describe("loadMolecule - wrong data", () => {
        let sut: Molecule3D;
        let jcifMin: any;
        beforeEach(() => {
            sut = new Molecule3D();
            jcifMin = {
                a: 1,
                b: 1,
                c: 1,
                alpha: 90,
                beta: 90,
                gamma: 90,
                sgHall: "-P 1",
                sg: "P -1",
                loops: [{
                  columns : ["_atom_site_fract_x", "_atom_site_fract_y", "_atom_site_fract_z"],
                  data : ["0.5", "0.5", "0.5"],
                }],
            };
        });

        it("should read simplest molecule", () => {
            MoleculeReaderJCIF.loadMolecule(sut, jcifMin);
        });

        it("should throw when no unit cell params provided", () => {
            jcifMin.gamma = "WRONG";
            expect(() => {
                MoleculeReaderJCIF.loadMolecule(sut, jcifMin);
            }).toThrow();
        });

        it("should throw when no sg provided", () => {
            jcifMin.sgHall = "";
            jcifMin.sg = "";
            expect(() => {
                MoleculeReaderJCIF.loadMolecule(sut, jcifMin);
            }).toThrow();
        });

        it("should throw when wrong sg provided", () => {
            jcifMin.sgHall = "";
            jcifMin.sg = "WRONG";
            expect(() => {
                MoleculeReaderJCIF.loadMolecule(sut, jcifMin);
            }).toThrow();
        });
    });

});
