import { Molecule3D } from "../Molecule3D";
import { MoleculeReaderJCIF } from "./MoleculeReaderJCIF";
import { JMol, MoleculeWriterJMOL } from "./MoleculeWriterJMOL";
export { JMol } from "./MoleculeWriterJMOL";

export class MoleculeIO {
    public static loadMolecule(
        molecule: Molecule3D,
        data: object | string,
        type: string,
    ) {
        const ext = (type || "").toLowerCase().trim();
        if (ext === "jcif") {
            MoleculeReaderJCIF.loadMolecule(molecule, data as object);
            return;
        }
        throw new Error("Unsupported type");
    }

    public static exportMolecule(
        molecule: Molecule3D,
        type: string,
    ): JMol[] {
        const ext = (type || "").toLowerCase().trim();

        if (ext === "jmol") {
            return MoleculeWriterJMOL.exportMolecule(molecule);
        }

        throw new Error("Unsupported type");
    }
}
