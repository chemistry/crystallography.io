import { Molecule3D } from "../Molecule3D";
import { MoleculeIO } from "./MoleculeIO";
import { MoleculeReaderJCIF } from "./MoleculeReaderJCIF";
import { MoleculeWriterJMOL } from "./MoleculeWriterJMOL";

describe("MoleculeIO", () => {

    const sut = MoleculeIO;

    it("should definde export", () => {
        expect(sut).toBeDefined();
    });

    describe("loadMolecule", () => {
        let molecule: Molecule3D;

        beforeEach(() => {
            spyOn(MoleculeReaderJCIF, "loadMolecule");

            molecule = new Molecule3D();
        });

        it("should throw error for unsupported file type", () => {
            expect(() => {
                MoleculeIO.loadMolecule(molecule, {}, "WRONG-TYPE");
            }).toThrow();
        });

        it("should call MoleculeReaderJCIF load for jcif format", () => {
            MoleculeIO.loadMolecule(molecule, {}, "jcif");

            expect(MoleculeReaderJCIF.loadMolecule).toHaveBeenCalled();
        });
    });

    describe("exportMolecule", () => {
        let molecule: Molecule3D;

        beforeEach(() => {
            spyOn(MoleculeWriterJMOL, "exportMolecule");
            molecule = new Molecule3D();
        });

        it("should throw error for unsupported file type", () => {
            expect(() => {
                MoleculeIO.exportMolecule(molecule, "WRONG-TYPE");
            }).toThrow();
        });

        it("should call MoleculeWriterJMOL jmol format", () => {
            MoleculeIO.exportMolecule(molecule, "jmol");

            expect(MoleculeWriterJMOL.exportMolecule).toHaveBeenCalled();
        });
    });
});
