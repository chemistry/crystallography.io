import { SpaceGroup } from "@crystallography/space-groups";
import { Molecule3D } from "../Molecule3D";
import { UnitCell } from "../UnitCell";

export class MoleculeWriterJMOL {

    public static readonly title = "jmol";
    public static readonly extension = ["jmol"];
    public static readonly description = "jmol molecule format";

    public static exportMolecule(molecule: Molecule3D): JMol[] {
        const fragments: JMol[] = [];
        const maxFragment = Math.max(0, ...molecule.cellAtoms.map((ca) => ca.fragmentId));
        if (isNaN(maxFragment)) {
            throw new Error("Connectivity is not set correctly");
        }
        for (let i = 1; i < maxFragment + 1; i ++) {
            const jmol = MoleculeWriterJMOL.exportFragment(molecule, i);
            fragments.push(jmol);
        }
        return fragments;
    }

    public static exportFragment(molecule: Molecule3D, fragmentId: number): JMol {
      let atoms: Array<[number, number, number, string, boolean, string]> = [];
      atoms = molecule.atoms
      .filter((atom) => {
          return atom.parent.fragmentId === fragmentId;
      })
      .map((atom) => {
          return [
              atom.position.x,
              atom.position.y,
              atom.position.z,
              atom.parent.element.symbol,
              atom.symetry.isE(),
              atom.symetry.toSymetryCode(),
          ];
      }) as (Array<[number, number, number, string, boolean, string]>);

      let bonds: Array<[number, number, number]> = [];

      bonds = molecule.bonds
      .filter((bond) => {
          return (bond.atom1.parent.fragmentId === fragmentId
            && bond.atom2.parent.fragmentId === fragmentId);
      })
      .map((bond) => {
          const bIdx1 = molecule.atoms.indexOf(bond.atom1) + 1;
          const bIdx2 = molecule.atoms.indexOf(bond.atom2) + 1;
          const order = bond.order;
          return [
              bIdx2,
              bIdx1,
              order,
          ];
      }) as (Array<[number, number, number]>);

      return {
          atoms,
          bonds,
          id : molecule.id || "",
          title: molecule.title || "",
      };
    }
}

/* tslint:disable:interface-name */
export interface JMol {
    atoms: Array<[number, number, number, string, boolean, string]>;
    bonds: Array<[number, number, number]>;
    id: string;
    title: string;
}
