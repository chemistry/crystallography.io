import { CellAtomsBuilder } from "../CellAtomsBuilder";
import { Molecule3D } from "../Molecule3D";
import { UnitCell } from "../UnitCell";
import { MoleculeWriterJMOL } from "./MoleculeWriterJMOL";

describe("MoleculeWriterJMOL", () => {

    it("should definde export", () => {
        expect(MoleculeWriterJMOL).toBeDefined();
    });

    describe("MoleculeWriterJMOL", () => {
        let molecule: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            builder = new CellAtomsBuilder();
            molecule = new Molecule3D();
        });

        it("should return object on exporting empty molecule", () => {
            const res = MoleculeWriterJMOL.exportMolecule(molecule);
            expect(typeof res).toEqual("object");
        });

        xit("should export data according to jmol format", () => {
            const ca1 = builder
              .withCoordinates(1, 1, 1)
              .withType("C")
              .build();
            molecule.addCellAtom(ca1);
            const sym1 = UnitCell.getMatrixFromSymetry("x,y,z");
            const atom1 = ca1.createAtom(sym1, true);
            const sym2 = UnitCell.getMatrixFromSymetry("-x,-y,-z");
            const atom2 = ca1.createAtom(sym2, true);
            molecule.addAtom(atom1);
            molecule.addAtom(atom2);
            molecule.id = "MOCK-ID";
            molecule.title = "MOCK-TITLE";

            const res = MoleculeWriterJMOL.exportMolecule(molecule);

            expect(res).toEqual(jasmine.objectContaining({
                id: "MOCK-ID",
                title: "MOCK-TITLE",
                atoms: [
                  jasmine.anything(),
                  jasmine.anything(),
                ],
            }) as any);

            // Check atoms params
            expect(res[0].atoms[0][0]).toBeCloseTo(1);
            expect(res[0].atoms[0][1]).toBeCloseTo(1);
            expect(res[0].atoms[0][2]).toBeCloseTo(1);
            expect(res[0].atoms[0][3]).toBe("C");
            expect(res[0].atoms[0][4]).toBe(true);
            expect(res[0].atoms[0][5]).toBe("x,y,z");

            expect(res[0].atoms[1][0]).toBeCloseTo(-1);
            expect(res[0].atoms[1][1]).toBeCloseTo(-1);
            expect(res[0].atoms[1][2]).toBeCloseTo(-1);
            expect(res[0].atoms[1][3]).toBe("C");
            expect(res[0].atoms[1][4]).toBe(false);
            expect(res[0].atoms[1][5]).toBe("-x,-y,-z");
        });
    });
});
