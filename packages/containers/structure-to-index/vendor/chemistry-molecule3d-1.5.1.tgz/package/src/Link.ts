import { Matrix3x4, Vec3 } from "@chemistry/math";
import { CellAtom } from "./CellAtom";

export class Link {

    public readonly fractional: Vec3;

    constructor(
        public atom: CellAtom,
        public symetry: Matrix3x4,
        public order?: number) {

        this.order = order || 1;
        this.fractional = symetry.project(atom.fractional);
    }

    public destroy() {
        this.atom = null;
        this.symetry = null;
    }
}
