import { Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { Atom } from "./Atom";
import { Bond } from "./Bond";
import { CellAtom, ICellAtomData } from "./CellAtom";
import { JMol, MoleculeIO } from "./io";
import { MoleculeBuilder } from "./MoleculeBuilder";
import { MoleculeConnector } from "./MoleculeConnector";
import { UnitCell } from "./UnitCell";

export class Molecule3D {
    public id: string = "";
    public title: string = "";
    public unitCell: UnitCell = new UnitCell(1, 1, 1, 90, 90, 90, SpaceGroup.getById(1));
    public cellAtoms: CellAtom[] = [];
    public atoms: Atom[] = [];
    public bonds: Bond[] = [];
    public initConnectivity: boolean = false;

    constructor() {
        this.clear();
    }

    public clear() {
        this.id = "";
        this.title = "";
        this.atoms.length = 0;
        this.bonds.length = 0;
        this.cellAtoms.length = 0;
    }

    public destroy() {
        this.id = undefined;
        this.title = undefined;
        this.unitCell = null;
        this.cellAtoms.forEach((cellAtom) => {
            cellAtom.destroy();
        });
        this.cellAtoms.length = 0;
        this.atoms.forEach((atom) => {
            atom.destroy();
        });
        this.atoms.length = 0;
        this.bonds.length = 0;
        this.bonds.forEach((bond) => {
            bond.destroy();
        });
    }

    public connectAtoms() {
        if (!this.initConnectivity) {
            this.initConnectivity = true;
            MoleculeConnector.buildConnectivity(this);
        }
    }

    public load(input: object | string) {
        this.initConnectivity = false;
        MoleculeIO.loadMolecule(this, input, "jcif");

        this.connectAtoms();

        MoleculeBuilder.addUniqueAtoms(this);
    }

    public getAtomsCount() {
        return this.atoms.length;
    }

    public addAtomLayers(count: number, atomsLimit: number) {
        MoleculeBuilder.addAtomLayers(this, count, atomsLimit);
    }

    public export(): JMol[] {
        return MoleculeIO.exportMolecule(this, "jmol");
    }

    public addCellAtom(data: ICellAtomData | CellAtom) {
        let atom: CellAtom;

        if (this.initConnectivity) {
            throw new Error("Connectivity alredy build");
        }

        if (data instanceof CellAtom) {
            atom = data as CellAtom;
        } else {
            atom = new CellAtom(data as ICellAtomData);
        }

        atom.setUnitCell(this.unitCell);
        atom.setId(this.cellAtoms.length + 1);
        this.cellAtoms.push(atom);
    }

    public isOrganic() {
        if (this.cellAtoms.length === 0) {
            return false;
        }
        return this.cellAtoms.some((atom) => {
            if (atom.element.symbol !== "C") {
                return false;
            }
            const links = atom.getLinks();
            return links.some((link) => {
                return link.atom.element.symbol === "C";
            });
        });
    }

    public addAtom(atom: Atom) {
        this.atoms.push(atom);
    }
}
