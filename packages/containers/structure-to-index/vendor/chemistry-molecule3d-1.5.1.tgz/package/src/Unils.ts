import { Matrix3x4 } from "@chemistry/math";

export class Utils {

    public static SymetryCodeToMatrix(code: string): Matrix3x4 {
        const s = replaceAll(code.toLowerCase(), " ", "");
        const parts = s.split(",");
        if (parts.length !== 3) {
            throw new Error("can not parse symetry code : " + code);
        }

        const xv = Utils.SymCodeSym1(parts[0]);
        const yv = Utils.SymCodeSym1(parts[1]);
        const zv = Utils.SymCodeSym1(parts[2]);

        for (let i = 0; i < 4; i++) {
            if (!isNumeric(xv[i]) || !isNumeric(yv[i]) || !isNumeric(zv[i]) ) {
                throw new Error("can not parse symetry code : " + code);
            }
        }

        return new Matrix3x4([
            xv[0], xv[1], xv[2], xv[3],
            yv[0], yv[1], yv[2], yv[3],
            zv[0], zv[1], zv[2], zv[3],
        ]);
    }

    private static SymCodeSym1(code: string): number[] {
        const res = [0, 0, 0, 0];
        const chunks = code.split("+");

        for (const chunk of chunks) {
            const res2 = Utils.SymCodeSym2(chunk);
            res[0] = res[0] + res2[0];
            res[1] = res[1] + res2[1];
            res[2] = res[2] + res2[2];
            res[3] = res[3] + res2[3];
        }
        return res;
    }

    private static SymCodeSym2(code: string): number[] {
        const res = [0, 0, 0, 0];
        const chunks = code.split("-");
        let res2 = [0, 0, 0, 0];

        for (let i = 0; i < chunks.length; i++) {
            if ((i === 0) && (chunks[i] === "")) {
                continue;
            }
            let sign = -1;
            if (i === 0) {
                sign = 1;
            }
            res2 = Utils.SymCodeSym3(chunks[i]);
            res[0] = res[0] + (res2[0] * sign);
            res[1] = res[1] + (res2[1] * sign);
            res[2] = res[2] + (res2[2] * sign);
            res[3] = res[3] + (res2[3] * sign);
        }
        return res;
    }

    private static SymCodeSym3(code: string): number[] {
        const res = [0, 0, 0, 0];
        if (code.indexOf("x") >= 0) {
            res[0] = Utils.SymCodeSym5(code, "x");
        } else if (code.indexOf("y") >= 0) {
            res[1] = Utils.SymCodeSym5(code, "y");
        } else if (code.indexOf("z") >= 0) {
            res[2] = Utils.SymCodeSym5(code, "z");
        } else {
            res[3] = Utils.SymCodeSym4(code);
        }
        return res;
    }

    private static SymCodeSym4(code: string): number {
        if (code.indexOf("/") !== -1) {
            const xpl = code.split("/");
            return parseFloat(xpl[0]) / parseFloat(xpl[1]);
        } else {
            const stp = code.replace(",", ".");
            return parseFloat(stp);
        }
    }

    private static SymCodeSym5(code: string, varName: string): number {
        if (code.indexOf("*") !== -1) {
            const xpl = code.split("*");
            if (xpl[1] !== varName) {
                throw new Error("can not parse symetry code");
            }
            return Utils.SymCodeSym4(xpl[0]);
        } else {
            if (varName === code) {
                return 1;
            }
            return Utils.SymCodeSym4(code.replace(varName, ""));
        }
    }
}

function isNumeric(n: any): boolean {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

function replaceAll(str: string, find: string, replace: string): string {
   return str.replace(new RegExp(find.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"), "g"), replace);
}
