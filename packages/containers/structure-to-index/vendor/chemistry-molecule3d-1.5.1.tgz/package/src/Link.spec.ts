import { Matrix3x4, Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { CellAtom } from "./CellAtom";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { Link } from "./Link";
import { UnitCell } from "./UnitCell";

describe("Link", () => {
    it("should export class", () => {
        expect(Link).toBeDefined();
    });

    describe("constructor", () => {
        let sut: Link;

        beforeEach(() => {
            const builder = new CellAtomsBuilder();
            const ca: CellAtom = builder
              .withCoordinates(1, 2, 3)
              .build();

            const symetry =  UnitCell.getMatrixFromSymetry("-x,-y,-z");

            sut = new Link(ca, symetry);
        });

        it("should be able to create instance", () => {
            expect(sut).toBeDefined();
        });

        it("should initialize default order", () => {
            expect(sut.order).toEqual(1);
        });

        it("should initialize fractional field", () => {
            expect(sut.fractional.toString()).toEqual("(-1.000,-2.000,-3.000)");
        });
    });
});
