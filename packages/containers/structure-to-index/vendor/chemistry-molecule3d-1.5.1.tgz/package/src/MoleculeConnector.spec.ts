import { Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { Molecule3D } from "./Molecule3D";
import { MoleculeConnector } from "./MoleculeConnector";
import { UnitCell } from "./UnitCell";

describe("Molecule3D", () => {
    const sut = MoleculeConnector;

    it("should export class", () => {
        expect(sut).toBeDefined();
    });

    describe("buildConnectivity", () => {
        let mol: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            mol = new Molecule3D();
            builder = new CellAtomsBuilder();
            spyOn(sut as any, "getMaxRCow").and.callThrough();
            spyOn(sut as any, "getCellAtomsBox").and.callThrough();
            spyOn(sut as any, "checkAndAddConnection").and.callThrough();
        });

        it("should define buildConnectivity method", () => {
            expect(sut.buildConnectivity).toBeDefined();
        });

        it("should return when no cellAtoms set", () => {
            expect(() => {
                sut.buildConnectivity(mol);
            }).not.toThrow();
            expect((sut as any).getMaxRCow).not.toHaveBeenCalled();
            expect((sut as any).getCellAtomsBox).not.toHaveBeenCalled();
        });

        it("should work with simplest molecule ", () => {
            const ca1 = builder.withType("C").build();
            mol.addCellAtom(ca1);
            expect(() => {
                sut.buildConnectivity(mol);
            }).not.toThrow();
        });

        it("should check evry connection ", () => {
            const ca1 = builder.withType("C").build();
            mol.addCellAtom(ca1);
            sut.buildConnectivity(mol);

            expect((sut as any).checkAndAddConnection).toHaveBeenCalledTimes(27);
        });

        it("should connect atoms located within unitcell", () => {
            mol = new Molecule3D();
            mol.unitCell = new UnitCell(10, 10, 10, 90, 90, 90, SpaceGroup.getById(1));
            const ca1 = builder.withCoordinates(0.5, 0.5, 0.5).build();
            const ca2 = builder.withCoordinates(0.64, 0.5, 0.5).build();
            const ca3 = builder.withCoordinates(0.75, 0.75, 0.75).build();
            mol.addCellAtom(ca1);
            mol.addCellAtom(ca2);
            mol.addCellAtom(ca3);

            sut.buildConnectivity(mol);

            expect(ca1.getLinks().length).toEqual(1);
            expect(ca2.getLinks().length).toEqual(1);
            expect(ca3.getLinks().length).toEqual(0);

            expect(ca1.getLinks()[0].atom).toEqual(ca2);
            expect(ca1.getLinks()[0].symetry.toString()).toEqual("(1.000,0.000,0.000,0.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
            expect(ca2.getLinks()[0].symetry.toString()).toEqual("(1.000,0.000,0.000,0.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
        });

        it("should auto detect and handle translations", () => {
            mol = new Molecule3D();
            mol.unitCell = new UnitCell(10, 10, 10, 90, 90, 90, SpaceGroup.getById(1));
            const ca1 = builder.withCoordinates(1.5, 0.5, 0.5).build();
            const ca2 = builder.withCoordinates(1.64, 0.5, 0.5).build();
            const ca3 = builder.withCoordinates(0.75, 0.75, 0.75).build();
            mol.addCellAtom(ca1);
            mol.addCellAtom(ca2);
            mol.addCellAtom(ca3);

            sut.buildConnectivity(mol);

            expect(ca1.getLinks().length).toEqual(1);
            expect(ca2.getLinks().length).toEqual(1);
            expect(ca3.getLinks().length).toEqual(0);

            expect(ca1.getLinks()[0].atom).toEqual(ca2);
            expect(ca1.getLinks()[0].symetry.toString()).toEqual("(1.000,0.000,0.000,0.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
            expect(ca2.getLinks()[0].symetry.toString()).toEqual("(1.000,0.000,0.000,0.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
        });

        it("should connect atoms from different units", () => {
            mol = new Molecule3D();
            mol.unitCell = new UnitCell(10, 10, 10, 90, 90, 90, SpaceGroup.getById(1));
            const ca1 = builder.withCoordinates(0.9, 0.5, 0.5).build();
            const ca2 = builder.withCoordinates(0.04, 0.5, 0.5).build();
            const ca3 = builder.withCoordinates(0.75, 0.75, 0.75).build();
            mol.addCellAtom(ca1);
            mol.addCellAtom(ca2);
            mol.addCellAtom(ca3);

            sut.buildConnectivity(mol);

            expect(ca1.getLinks().length).toEqual(1);
            expect(ca2.getLinks().length).toEqual(1);
            expect(ca3.getLinks().length).toEqual(0);

            expect(ca1.getLinks()[0].atom).toEqual(ca2);
            expect(ca1.getLinks()[0].symetry.toString()).toEqual("(1.000,0.000,0.000,1.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
            expect(ca2.getLinks()[0].symetry.toString()).toEqual("(1.000,0.000,0.000,-1.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
        });
    });

    describe("getCellAtomsBox", () => {
        let mol: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            mol = new Molecule3D();
            builder = new CellAtomsBuilder();
        });

        it("should get defined box", () => {
            const ca1 = builder.withCoordinates(0.1, 0.1, -1).build();
            const ca2 = builder.withCoordinates(1, 1, 1).build();
            const ca3 = builder.withCoordinates(1, 3, 4).build();
            const ca4 = builder.withCoordinates(0.5, 1.5, 2).build();
            mol.addCellAtom(ca1);
            mol.addCellAtom(ca2);
            mol.addCellAtom(ca3);
            mol.addCellAtom(ca4);

            const box = (MoleculeConnector as any).getCellAtomsBox(mol);

            expect(box[0].toString()).toEqual("(0.100,0.100,-1.000)");
            expect(box[1].toString()).toEqual("(1.000,3.000,4.000)");
        });

        it("should work correctly with only one atom", () => {
            const ca1 = builder.withType("C").build();
            mol.addCellAtom(ca1);

            const box = (MoleculeConnector as any).getCellAtomsBox(mol);

            expect(box[0].toString()).toEqual("(0.000,0.000,0.000)");
            expect(box[1].toString()).toEqual("(0.000,0.000,0.000)");
        });
    });

    describe("getMaxRCow", () => {
        let mol: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            mol = new Molecule3D();
            builder = new CellAtomsBuilder();
        });

        it("should return atom with bigest radius: I in set(H,I,C)", () => {
            const ca1 = builder.withType("H").build();
            const ca2 = builder.withType("I").build();
            const ca3 = builder.withType("C").build();

            mol.addCellAtom(ca1);
            mol.addCellAtom(ca2);
            mol.addCellAtom(ca3);

            const maxRCow = (MoleculeConnector as any).getMaxRCow(mol);

            expect(maxRCow).toEqual(ca2.element.RCow);
        });
    });

    describe("fillFragmentsIds", () => {
        let mol: Molecule3D;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            mol = new Molecule3D();
            builder = new CellAtomsBuilder();
        });

        it("should set fragment id based on cellAtoms connections", () => {
            mol.unitCell = new UnitCell(10, 10, 10, 90, 90, 90, SpaceGroup.getById(1));

            const ca1 = builder.withCoordinates(0.5, 0.5, 0.5).build();
            const ca2 = builder.withCoordinates(0.64, 0.5, 0.5).build();
            const ca3 = builder.withCoordinates(0.75, 0.75, 0.75).build();
            mol.addCellAtom(ca1);
            mol.addCellAtom(ca2);
            mol.addCellAtom(ca3);

            sut.buildConnectivity(mol);

            expect(ca1.fragmentId).toEqual(1);
            expect(ca2.fragmentId).toEqual(1);
            expect(ca3.fragmentId).toEqual(2);
        });
    });

});
