import { Matrix3x4, Vec3 } from "@chemistry/math";
import { CellAtom } from "./CellAtom";
import { Molecule3D } from "./Molecule3D";
import { UnitCell } from "./UnitCell";

const CW_BOND_FROM = 0.4;
const CW_BOND_TO = 1.2;

export class MoleculeConnector {

    public static buildConnectivity(molecule: Molecule3D) {
        if (molecule.cellAtoms.length === 0) {
            return;
        }

        const atomBox = MoleculeConnector.getCellAtomsBox(molecule);
        const maxRCow = MoleculeConnector.getMaxRCow(molecule);

        const cellAtoms = molecule.cellAtoms;
        const unitCell = molecule.unitCell;
        const symetryList = molecule.unitCell.symetryList;
        const translations = UnitCell.getBoxTransactions();

        const p1 = atomBox[0].sub(new Vec3(2 * maxRCow, 2 * maxRCow, 2 * maxRCow));
        const p2 = atomBox[1].add(new Vec3(2 * maxRCow, 2 * maxRCow, 2 * maxRCow));

        // Iterate over cell atoms, transactions & symetry
        for (let i = 0; i < cellAtoms.length; i++) {
            const catom = cellAtoms[i];

            for (const symetry of symetryList) {

                const pre1 = symetry.project(catom.fractional);
                const pre2 = Vec3.getDecimal(pre1);
                const transFromOrign = Vec3.sub(pre1, pre2);

                for (const tr of translations) {
                    const pre3 = Vec3.add(pre2, tr);
                    const pred = unitCell.fractToOrth(pre3);

                    if (
                        ((p1.x <= pred.x) && (p2.x >= pred.x)) &&
                        ((p1.y <= pred.y) && (p2.y >= pred.y)) &&
                        ((p1.z <= pred.z) && (p2.z >= pred.z))
                    ) {
                        const trans =  Vec3.sub(tr, transFromOrign);
                        const sym = symetry.translate(trans);

                        MoleculeConnector.checkAndAddConnection(cellAtoms, i, catom, sym, pred);
                    }
                }
            }
        }

        MoleculeConnector.fillFragmentsIds(molecule);
    }

    private static fillFragmentsIds(molecule: Molecule3D) {
        if (molecule.cellAtoms.length === 0) {
            return;
        }

        const cellAtoms = molecule.cellAtoms.slice(0);
        let fragmentId = 0;

        for (const ca of cellAtoms) {
            ca.setFragmentId(0);
        }

        while (cellAtoms.length > 0) {
            const ca = cellAtoms.shift();
            if (ca.fragmentId !== 0) {
                continue;
            }
            fragmentId ++;

            const queue: CellAtom[] = [];
            queue.push(ca);

            while (queue.length > 0) {
                const curr = queue.shift();
                const links = curr.getLinks();
                curr.setFragmentId(fragmentId);

                links.forEach((link) => {
                    if (link.atom.fragmentId === 0) {
                        link.atom.setFragmentId(fragmentId);
                        queue.push(link.atom);
                    }
                });
            }
        }
    }

    private static checkAndAddConnection(
        cellAtoms: CellAtom[],
        i: number,
        catom: CellAtom,
        symetry: Matrix3x4,
        pred: Vec3,
    ) {
        if (catom.group && catom.group !== "-1" && catom.group !== "1") {
            return;
        }
        for (let m = i + 1; m < cellAtoms.length; m++) {
            const catom2 = cellAtoms[m];
            if (catom2.group && catom2.group !== "-1" && catom2.group !== "1") {
                continue;
            }

            const l = (new Vec3(
                catom2.position.x - pred.x,
                catom2.position.y - pred.y,
                catom2.position.z - pred.z,
            )).length;

            const r = catom.element.RCow + catom2.element.RCow;
            if ((l <= r * CW_BOND_TO) && (l >= r * CW_BOND_FROM)) {

                if (!catom2.hasLink(catom, symetry.project(catom.fractional))) {
                    const symInverse = symetry.inverse();

                    catom2.addLink(catom, symetry);
                    catom.addLink(catom2, symInverse);
                }
            }
        }

        return;
    }

    private static getMaxRCow(molecule: Molecule3D) {
        const cellAtoms = molecule.cellAtoms;
        let maxRCow = -Infinity;
        for (const atom of cellAtoms) {
            maxRCow = atom.element.RCow > maxRCow ? atom.element.RCow : maxRCow;
        }
        return maxRCow;
    }

    private static getCellAtomsBox(molecule: Molecule3D): [Vec3, Vec3] {
        const cellAtoms = molecule.cellAtoms;
        const p1 = new Vec3(Infinity, Infinity, Infinity);
        const p2 = new Vec3(-Infinity, -Infinity, -Infinity);

        for (const atom of cellAtoms) {
            p1.x = atom.position.x < p1.x ? atom.position.x : p1.x;
            p1.y = atom.position.y < p1.y ? atom.position.y : p1.y;
            p1.z = atom.position.z < p1.z ? atom.position.z : p1.z;

            p2.x = atom.position.x > p2.x ? atom.position.x : p2.x;
            p2.y = atom.position.y > p2.y ? atom.position.y : p2.y;
            p2.z = atom.position.z > p2.z ? atom.position.z : p2.z;
        }
        return [p1, p2];
    }
}
