import { Matrix3x3, Matrix3x4, Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { UnitCell } from "./UnitCell";

describe("UnitCell", () => {
    it("should export class", () => {
        expect(UnitCell).toBeDefined();
    });

    it("should be able to create instance", () => {
        const sg = SpaceGroup.getById(1);
        const uc = new UnitCell(1, 1, 1, 90, 90, 90, sg);
        expect(uc).toBeDefined();
    });

    describe("fractToOrth", () => {
        it("should scale to 2 simple cubic uc with edges 2", () => {
            const sg = SpaceGroup.getById(1);
            const uc = new UnitCell(2, 2, 2, 90, 90, 90, sg);
            const v = uc.fractToOrth(new Vec3(1, 0.5, 1));

            expect(v.toString()).toBeDefined("(2.000,1.000,2.000)");
        });
    });

    describe("orthToFract", () => {
      it("should scale to 0.5 cubic uc with edges 2", () => {
          const sg = SpaceGroup.getById(1);
          const uc = new UnitCell(2, 2, 2, 90, 90, 90, sg);
          const v = uc.orthToFract(new Vec3(2, 4, 1));

          expect(v.toString()).toBeDefined("(1.000,2.000,0.500)");
      });
    });

    describe("getMatrixFromSymetry", () => {
        it("should process x,y,z symetry", () => {
            const m = UnitCell.getMatrixFromSymetry("x,y,z");
            expect(m.toString()).toEqual("(1.000,0.000,0.000,0.000,0.000,1.000,0.000,0.000,0.000,0.000,1.000,0.000)");
        });
    });

    describe("getBoxTransactions", () => {
        it("should return all posible transactions", () => {
            const trans = UnitCell.getBoxTransactions();
            expect(trans.length).toEqual(27);
        });

        it("should give E transaction as first", () => {
            const trans = UnitCell.getBoxTransactions();
            expect(trans[0].toString()).toEqual("(0.000,0.000,0.000)");
        });
    });
});
