import { Element } from "@chemistry/elements";
import { Matrix3x4, Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { Atom } from "./Atom";
import { Link } from "./Link";
import { UnitCell } from "./UnitCell";

export interface ICellAtomData {
    type: string;
    label?: string;
    x: number;
    y: number;
    z: number;
    occupancy: number;
    uiso: number;
    asembly: string;
    group: string;
}

export class CellAtom {

    public readonly id: number;
    public readonly label: string;
    public readonly element: Element;
    public readonly position: Vec3;
    public readonly fractional: Vec3;
    public readonly occupancy: number;
    public readonly uiso: number;
    public readonly fragmentId: number;
    public readonly asembly: string;
    public readonly group: string;

    public readonly unitCell: UnitCell;

    private readonly links: Link[] = [];
    private readonly children: Atom[] = [];

    constructor(data: ICellAtomData) {

        const element = Element.getElementByName(data.type);
        if (!element) {
            throw new Error("Wrong Element Name or ID: " + element);
        }

        this.element = element;

        this.label = data.label || element.symbol || "";

        this.fractional = new Vec3(data.x, data.y, data.z);
        this.occupancy = data.occupancy;
        this.uiso = data.uiso;
        this.asembly = data.asembly;
        this.group = data.group;
    }

    public setUnitCell(unitCell: UnitCell) {
        (this as any).unitCell = unitCell;
        (this as any).position =  this.unitCell.fractToOrth(this.fractional);
    }

    public setId(id: number) {
        (this as any).id = id;
    }

    public setFragmentId(fragmentId: number) {
        (this as any).fragmentId = fragmentId;
    }

    public addLink(otherAtom: CellAtom, symetry: Matrix3x4) {
        const link = new Link(otherAtom, symetry);
        this.links.push(link);
    }

    public hasLink(otherAtom: CellAtom, position: Vec3) {
        if (!this.links.length) {
            return false;
        }

        return this.links.some((link) => {
            return (link.atom === otherAtom && link.fractional.equal(position));
        });
    }

    public getLinks() {
        return this.links;
    }

    public getChildren() {
        return this.children;
    }

    public createAtom(symetry: Matrix3x4, addToChields: boolean): Atom {
        const atom = new Atom(this, symetry);
        if (addToChields) {
            this.children.push(atom);
        }
        return atom;
    }

    public hasChild(position: Vec3): boolean {
        for (const ch of this.children) {
            if (ch.fractional.equal(position)) {
                 return true;
            }
        }
        return false;
   }

   public getChild(position: Vec3): Atom {
       for (const ch of this.children) {
           if (ch.fractional.equal(position)) {
               return ch;
           }
       }
       return null;
   }

   public destroy() {
        this.links.forEach((link) => {
            link.destroy();
        });
        (this as any).links.length = 0;
        (this as any).children.length = 0;
        (this as any).element = undefined;
        (this as any).label = undefined;
        (this as any).asembly = undefined;
        (this as any).group = undefined;

        (this as any).unitCell = null;
        (this as any).position = null;
        (this as any).fractional = null;

   }
}
