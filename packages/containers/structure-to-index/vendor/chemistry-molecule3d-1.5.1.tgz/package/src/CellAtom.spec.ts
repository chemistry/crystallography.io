import { Matrix3x4, Vec3 } from "@chemistry/math";
import { SpaceGroup } from "@crystallography/space-groups";
import { CellAtom } from "./CellAtom";
import { CellAtomsBuilder } from "./CellAtomsBuilder";
import { UnitCell } from "./UnitCell";

describe("CellAtom", () => {

    it("should export class", () => {
        expect(CellAtom).toBeDefined();
    });

    describe("constructor", () => {
        let sut: CellAtom;
        let uc: UnitCell;
        let data: any;

        beforeEach(() => {
            uc = new UnitCell(1, 1, 1, 90, 90, 90);
            data = {
              type: "C",
              label: "C1",
              x: 1,
              y: 2,
              z: 3,
              occupancy: 1,
              uiso: 0,
              group: "",
              asembly: "",
            };
            sut = new CellAtom(data);
        });

        it("should create instance", () => {
            expect(sut).toBeDefined();
        });

        it("should initialize fields", () => {
            expect(sut.label).toEqual("C1");
            expect(sut.fractional.x).toBeCloseTo(1);
            expect(sut.fractional.y).toBeCloseTo(2);
            expect(sut.fractional.z).toBeCloseTo(3);
            expect(sut.occupancy).toBeCloseTo(1);
            expect(sut.uiso).toBeCloseTo(0);
        });

        it("should throw error then initialized with wrong with element name", () => {
            expect(() => {
                data.type = "WRONG ATOM TYPE";
                sut = new CellAtom(data);
            }).toThrow();
        });
    });

    describe("setUnitCell", () => {
        let sut: CellAtom;
        let uc: UnitCell;
        let data: any;

        beforeEach(() => {
            uc = new UnitCell(4, 4, 4, 90, 90, 90);
            data = {
              type: "C",
              label: "C1",
              x: 1,
              y: 2,
              z: 3,
              occupancy: 1,
              uiso: 0,
              group: "",
              asembly: "",
            };
            sut = new CellAtom(data);
        });
        it("should set unit cell & initialize ", () => {
            sut.setUnitCell(uc);
            expect(sut.unitCell).toBe(uc);
            expect(sut.position.toString()).toEqual("(4.000,8.000,12.000)");
        });
    });

    describe("setId", () => {
        let sut: CellAtom;

        beforeEach(() => {
            const data = {
              type: "C",
              label: "C1",
              x: 1,
              y: 2,
              z: 3,
              occupancy: 1,
              uiso: 0,
              group: "",
              asembly: "",
            };
            sut = new CellAtom(data);
        });

        it("should set id", () => {
            sut.setId(101);
            expect(sut.id).toEqual(101);
        });
    });

    describe("addLink", () => {
        let sut: CellAtom;
        let builder: CellAtomsBuilder;

        beforeEach(() => {
            builder = new CellAtomsBuilder();
            sut = builder.build();
        });

        it("should add created link to links array", () => {
            const ca = builder.build();
            const sg = UnitCell.getMatrixFromSymetry("x,y,z");

            sut.addLink(ca, sg);
            expect(sut.getLinks().length).toEqual(1);
        });
    });

    describe("createAtom", () => {
        let sut: CellAtom;
        let builder: CellAtomsBuilder;
        let symetry: Matrix3x4;

        beforeEach(() => {
            builder = new CellAtomsBuilder();
            sut = builder.build();
            symetry = UnitCell.getMatrixFromSymetry("x,y,z");
        });

        it("should create instance of Atom", () => {
            const atom = sut.createAtom(symetry, false);

            expect(atom).toBeDefined();
            expect((sut as any).children.length).toEqual(0);
        });

        it("should add created atom to children if addToChields is true", () => {
            const atom = sut.createAtom(symetry, true);

            expect(atom).toBeDefined();
            expect((sut as any).children.length).toEqual(1);
        });
    });

    describe("hasChild", () => {
        let sut: CellAtom;
        let builder: CellAtomsBuilder;
        let symetry: Matrix3x4;

        beforeEach(() => {
            builder = new CellAtomsBuilder();
            sut = builder.withCoordinates(1, 1, 1).build();
            symetry = UnitCell.getMatrixFromSymetry("x,-y,z");
        });

        it("should not find children by default", () => {
            sut.createAtom(symetry, true);

            expect(sut.hasChild(new Vec3(-10, -10, -10))).toBe(false);
        });

        it("should find specifies children", () => {
            sut.createAtom(symetry, true);

            expect(sut.hasChild(new Vec3(1, -1, 1))).toBe(true);
        });
    });

    describe("getChild", () => {
        let sut: CellAtom;
        let builder: CellAtomsBuilder;
        let symetry: Matrix3x4;

        beforeEach(() => {
            builder = new CellAtomsBuilder();
            sut = builder.withCoordinates(1, 1, 1).build();
            symetry = UnitCell.getMatrixFromSymetry("x,-y,z");
        });

        it("should return null for crazy coords", () => {
            sut.createAtom(symetry, true);

            expect(sut.getChild(new Vec3(-10, -10, -10))).toBe(null);
        });

        it("should find specifies children atom", () => {
            const atom = sut.createAtom(symetry, true);

            expect(sut.getChild(new Vec3(1, -1, 1))).toBe(atom);
        });
    });
});
