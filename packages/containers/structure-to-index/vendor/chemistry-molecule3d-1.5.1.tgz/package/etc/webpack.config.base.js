const path = require('path');
const webpack = require('webpack');

module.exports = {
    mode: 'production',

    devtool:  'source-map',

    entry: {
        'molecule3d': path.resolve(__dirname, '../src/Molecule3D')
    },

    output: {
        globalObject: 'typeof self !== \'undefined\' ? self : this',
        path: path.resolve(__dirname, '../dist'),
        filename: "[name].js",
        libraryTarget: 'umd',
        library: 'molecule3d',
        umdNamedDefine: true
    },

    module: {
        rules: [{
            test: /\.ts$/,
            exclude: /node_modules/,
            loader: 'awesome-typescript-loader'
        }],
    },

    plugins: [
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify('production'),
        })
    ],

    resolve: {
        extensions: ['.js', '.ts']
    }
};
